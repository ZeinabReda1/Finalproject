# To Run Project
    php artisan serve
# To Run Test 
    php vendor/bin/phpunit
        -- or
    composer test

# Import Postmain Collection  

    api.postman_collection.json


# What I Do In This Task

`1 - I use JWT to Auth User`

`2 - Api to create user`

`3 - Api to login user`

`4 - Api to logout user`

`5 - Api to show all users posts soretd `

`6 - Api to show specific post`



