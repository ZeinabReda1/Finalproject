<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::post('login', 'AuthController@authenticate');
Route::post('register', 'AuthController@register');

Route::group(['middleware' => ['jwt.verify']], function() {

    Route::get('logout', 'AuthController@logout');

    Route::group(['prefix' => 'posts'] , function (){
        Route::post('/' , 'PostController@store');
        Route::get('/' , 'PostController@index');
        Route::get('/{id}' , 'PostController@show');
    });


Route::get('orders', 'OrdersController@index');
Route::get('previous-orders', 'OrdersController@prevOrders');
Route::get('orders/{id}', 'OrdersController@view');
Route::post('make-order', 'OrdersController@makeOrder');
Route::put('update-order/{id}', 'OrdersController@update');
Route::get('remove-order/{id}', 'OrdersController@destroy');

Route::get('cart', 'CartController@cartList');
Route::get('cart/{id}', 'CartController@viewCart');
Route::post('store-cart', 'CartController@addToCart');
Route::post('update-cart-item/{id}', 'CartController@updateCart');
Route::get('remove-cart-item/{id}', 'CartController@removeCart');

});
